package org.example.controller;

public class BookIdMismatchException extends RuntimeException
{
}
